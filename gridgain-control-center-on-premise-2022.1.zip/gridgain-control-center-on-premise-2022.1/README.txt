Requirements
-------------------------------------
1. JDK 8 suitable for your platform.
2. Supported browsers: Chrome, Firefox, Safari, Edge.

How to run
-------------------------------------
1. Unpack gridgain-control-center-<edition>-<version>.zip to some folder.
2. Change work directory to folder where GridGain Control Center was unpacked.
3. Start control-center.{bat|sh} executable for you platform.

4. Open URL `localhost:3000` in browser.
5. Sign up to create a user.

Technical details
-------------------------------------
1. Package content:
    `libs` - this folder contains GridGain Control Center dependencies.
    `work` - this folder contains all GridGain Control Center data (registered users, created objects, ...) and
     should be preserved in case of update to new version.
2. Gridgain Control Center will start on default HTTP port `3000` and bind to all interfaces `0.0.0.0`.


You can use properties files, YAML files, environment variables to externalize configuration.

Properties are considered in the following order:
1. Java System properties (System.getProperties()).
2. OS environment variables.
3. Properties in /config subdirectory of the work directory or in work directory (application.properties and YAML variants).
   YAML format description can be found here https://docs.spring.io/spring-boot/docs/current/reference/html/boot-features-external-config.html#boot-features-external-config-yaml


Various properties can be specified inside your application.properties file, inside your application.yml file, or Java System properties.
This appendix provides a list of common Spring Boot properties and references to the underlying classes that consume them:

# Sign up configuration.
account.signup.enabled=true # Enable self registration
account.anonymous.enabled=true # Enable anonymous account creation via a link from the node log.
account.anonymous.cleanup-timeout=0 # Cleanup timeout in milliseconds at which Control Center delete anonymous account. If 0, anonymous accounts will never be deleted.
account.activation.enabled=false # Enable account activation
account.activation.timeout=1800000 # Activation timeout(milliseconds)
account.activation.send-timeout=180000 # Activation send email throttle (milliseconds)

# Sign in configuration.
account.authentication.max-attempts=Infinity # Specifies the maximum number of failed attempts allowed before preventing login.
account.authentication.interval=100 # Specifies the interval in milliseconds between login attempts, which increases exponentially based on the number of failed attempts (milliseconds).
account.authentication.max-interval=300000 # Specifies the maximum amount of time an account can be locked (milliseconds).

account.global-team.enabled=false # Enable global team, includes all users.
account.global-team.attach-cluster=false # Automatic cluster attachment to the global team after a successful handshake.

# Embedded server configuration.
server.address=0.0.0.0 # Network address to which the GridGain Control Center should bind.
server.port=3000 # GridGain Control Center port.
control.repositories.configurations.GccSessionCache.touch-expiration-timeout=604800000 # The number of milliseconds that the user session should be kept alive (default: 7 days).
control.repositories.auto-migrate-enabled=false # Enable auto migration of internal storage.
control.metric.ttl= # Metrics TTL in days after that they will be removed. Set 0 for infinity TTL (default: 1 day).
control.base-url= # Control Center url for links in notifications.
control.browsers.allowed-origins= # A comma-separated allowed origins for the WebSocket browsers endpoint.

# Repositories configuration
control.repositories.configurations.{cacheName}.data-region-name= # Custom data region for the cache. The property can be used for storing browser sessions (GccSessionCache) in the in-memory data region.

# Metrics collection configuration.
control.metric-collector.limit-enabled=true # Metrics limit enabled flag. If false, all the metrics will be collected from a cluster. Otherwise, metrics will be collected on demand.
control.metric-collector.limit-file-path=classpath:metrics.yml # The path to yaml file with metric templates that must always be collected. Has no effect if limit-enabled is false.

# Email (MailProperties)
spring.mail.default-encoding=UTF-8 # Default MimeMessage encoding.
spring.mail.host= # SMTP server host. For instance, `smtp.example.com`.
spring.mail.jndi-name= # Session JNDI name. When set, takes precedence over other Session settings.
spring.mail.port= # SMTP server port.
spring.mail.properties.*= # Additional JavaMail Session properties.
spring.mail.protocol=smtp # Protocol used by the SMTP server.
spring.mail.test-connection=false # Whether to test that the mail server is available on startup.
spring.mail.username= # Login user of the SMTP server.
spring.mail.password= # Login password of the SMTP server.

# SMS (SmsProperties) - currently Control Center supports "vonage.com" only.
nexmo.creds.api-key= # API key from account.
nexmo.creds.api-secret= # API secret from account.
nexmo.creds.from= # The name or number the message should be sent from.

# SSL options.
server.ssl.ciphers= # Supported SSL ciphers.
server.ssl.client-auth= # Client authentication mode.
server.ssl.enabled=true # Whether to enable SSL support.
server.ssl.enabled-protocols= # Enabled SSL protocols.
server.ssl.key-alias= # Alias that identifies the key in the key store.
server.ssl.key-password= # Password used to access the key in the key store.
server.ssl.key-store= # Path to the key store that holds the SSL certificate (typically a jks file).
server.ssl.key-store-password= # Password used to access the key store.
server.ssl.key-store-provider= # Provider for the key store.
server.ssl.key-store-type= # Type of the key store.
server.ssl.protocol=TLS # SSL protocol to use.
server.ssl.trust-store= # Trust store that holds SSL certificates.
server.ssl.trust-store-password= # Password used to access the trust store.
server.ssl.trust-store-provider= # Provider for the trust store.
server.ssl.trust-store-type= # Type of the trust store.

# Rate limit
control.rate-limit.ban-duration-seconds= # Time of ban.
control.rate-limit.candidates= # Number of candidates that would be banned with top statistics.
control.rate-limit.hard-limit= # Number of messages in the queue.
control.rate-limit.soft-limit= # Number of messages in the queue.
control.rate-limit.disconnected-lifetime-seconds= # Time how long does the rate limit session live without connection.
control.rate-limit.update-interval-millis= # Scheduled interval for alert check.
control.rate-limit.remove-session-interval-millis= # Scheduled interval for session removing check.

# OpenID Connect configuration. Replace XXXXX with your provider name.
spring.security.oauth2.client.registration.XXXXX.client-id= # Registered client ID in provider.
spring.security.oauth2.client.registration.XXXXX.client-secret= # Secret for registered client ID.
spring.security.oauth2.client.provider.XXXXX.authorization-uri= # Authorization URI for the provider.
spring.security.oauth2.client.provider.XXXXX.token-uri= # Token URI for the provider.
spring.security.oauth2.client.provider.XXXXX.jwk-set-uri= # JWK set URI for the provider.
control.base-url= # Control Center url. If frontend and backend have different hosts/ports, please add a value for the property equals to frontend’s uri (e.g. https://example.com:1234).


# Active Directory configuration.
Control Center can be configured to use Active Directory as a source of user information.

Active Directory integration uses "BIND" operation to authenticate users.

NOTE: Active Directory integration cannot be used together with native or OpenID-Connect-based authentication.

spring.activedirectory.urls= # URLs of the server, separated by comma. Example: ldap://localhost:389,ldap://localhost:8389
spring.activedirectory.domain= # Default domain name, which can be added to the user login, if the domain is not specified. Example: gridgain.org
spring.activedirectory.rootDn= # Base path from which all operations should originate. Example: dc=gridgain,dc=org
spring.activedirectory.adminRole="Domain Admins" # The name of the user group with admin permissions.


# LDAP configuration.
Control Center can be configured to use LDAP as a source of user information.

By default, LDAP integration uses password comparison authenticator which compares the login password with the value
stored in the directory using a remote LDAP "compare" operation.

NOTE: LDAP integration cannot be used together with native or OpenID-Connect-based authentication.

spring.ldap.urls= # LDAP URLs of the server, separated by comma. Example: ldap://localhost:389,ldap://localhost:8389
spring.ldap.base= # Base path from which all operations should originate. Example: dc=gridgain,dc=org
spring.ldap.admin-role=admin # The name of the user group with admin permissions.
spring.ldap.bind-authenticator.enabled=false # Enable authenticator which binds as a user.
spring.ldap.password-comparison-authenticator.password-attribute-name=userPassword # The field name where the password is stored.
spring.ldap.user-details.group-role-attribute=cn # The ID of the attribute which contains the role name for a group.
spring.ldap.user-details.group-member-attributeName=uniquemember # Name of the multi-valued attribute which holds the DNs of users who are members of a group.
spring.ldap.user-details.group-search-base=ou=groups # The Distinguished Name under which groups are stored.
spring.ldap.user-details.user-search-base=ou=people # The Distinguished Name under which users are stored.
spring.ldap.user-details.user-search-filter=uid={0} # The filter expression used in the user search. This is an LDAP search filter (as defined in 'RFC 2254') with optional arguments.


HTTPS setup (with self-signed certificate) between cluster and GridGain Control Center
-------------------------------------
1. Generate self-signed certificate.
2. Configure GridGain Control Center to use SSL port: 443 and key-store with generated certificate.
3. Configure you cluster to use SSL with help of control.sh utility.
For more information execute: JVM_OPTS='-DIGNITE_ENABLE_EXPERIMENTAL_COMMAND=true' control.sh --management help

For example, the properties for GridGain Control Center can be specified as:
server.port=443
server.ssl.key-store-type=JKS
server.ssl.key-store=certificates/server.jks
server.ssl.key-store-password=change_me


Database(s) configuration
-------------------------------------
The following property can be used to specify custom database(s) configuration in "application.properties":
ignite.configurations=<Path to configuration file or XML configuration>

Or using environment variable:
IGNITE_CONFIGURATIONS=<Path to configuration file or XML configuration>

Or using system properties:
-Dignite.configurations=<Path to configuration file or XML configuration>

For example:
ignite.configurations=classpath:ignite-config.xml
ignite.configurations=file:\some\path\custom-ignite-config.xml
ignite.configurations=<?xml version... XML content ...>

Configuration "classpath:ignite-config.xml" - will be used as default and available out of the box.
It contains configuration for single-node isolated cluster and suitable for development or small production usages.

This is an example of default Control Center configuration that can be changed over ignite.configurations property:
-------------------------------------
<?xml version="1.0" encoding="UTF-8"?>

<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">
    <bean class="org.apache.ignite.configuration.IgniteConfiguration">
        <property name="consistentId" value="ggcc-db"/>
        <property name="metricsLogFrequency" value="0"/>

        <!-- Disable all clients. -->
        <property name="connectorConfiguration"><null/></property>
        <property name="clientConnectorConfiguration"><null/></property>

        <!-- Persistence required to store user data on disk. -->
        <property name="dataStorageConfiguration">
            <bean class="org.apache.ignite.configuration.DataStorageConfiguration">
                <property name="defaultDataRegionConfiguration">
                    <bean class="org.apache.ignite.configuration.DataRegionConfiguration">
                        <property name="persistenceEnabled" value="true"/>
                        <!-- Set region size, because default size is 20% of physical memory available on current machine. -->
                        <property name="maxSize" value="#{256 * 1024 * 1024}"/>
                    </bean>
                </property>
            </bean>
        </property>

        <!-- Logging configuration. -->
        <property name="gridLogger">
            <bean class="org.apache.ignite.logger.log4j2.Log4J2Logger">
                <constructor-arg type="java.lang.String" value="log4j2.xml"/>
            </bean>
        </property>

        <property name="communicationSpi">
            <bean class="org.gridgain.gmc.discovery.IsolatedCommunicationSpi"/>
        </property>

        <property name="discoverySpi">
            <bean class="org.gridgain.gmc.discovery.IsolatedDiscoverySpi"/>
        </property>
    </bean>
</beans>

It is possible to setup separate data storage for users data, metrics and traces.
In this case GridGain Control Center will start three internal client nodes to connect to external clusters.
This will improve scalability and fault tolerance of GridGain Control Center.
To achieve this goal, define Spring XML configuration with three beans of IgniteConfiguration for three clients
that should connect to different clusters and pass it to GridGain Control Center via "ignite.configurations" property.

Beans should have the following predefined names: USERS_IGNITE_CONFIG, METRICS_IGNITE_CONFIG and TRACES_IGNITE_CONFIG, COMPUTE_IGNITE_CONFIG.

This is an example of how the Control Center can be configured to store its internal information in three different GridGain clusters:
-------------------------------------
<?xml version="1.0" encoding="UTF-8"?>

<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
       http://www.springframework.org/schema/beans/spring-beans.xsd">
    <!-- Client node for connecting to database with users data. -->
    <bean class="org.apache.ignite.configuration.IgniteConfiguration" name="USERS_IGNITE_CONFIG">
        <property name="clientMode" value="true"/>

        <!-- Setup discovery to cluster with users data. -->
        <property name="discoverySpi">
            <bean class="org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi">
                <property name="localPort" value="47500"/>
                <property name="ipFinder">
                    <bean class="org.apache.ignite.spi.discovery.tcp.ipfinder.vm.TcpDiscoveryVmIpFinder">
                        <property name="addresses">
                            <list>
                                <value>127.0.0.1:47500</value>
                            </list>
                        </property>
                    </bean>
                </property>
            </bean>
        </property>

        <!-- Other settings -->
    </bean>

    <!-- Client node for connecting to database with metrics. -->
    <bean class="org.apache.ignite.configuration.IgniteConfiguration" name="METRICS_IGNITE_CONFIG">
        <property name="clientMode" value="true"/>

        <!-- Setup discovery to cluster with metrics. -->
        <property name="discoverySpi">
            <bean class="org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi">
                <property name="localPort" value="47600"/>
                <property name="ipFinder">
                    <bean class="org.apache.ignite.spi.discovery.tcp.ipfinder.vm.TcpDiscoveryVmIpFinder">
                        <property name="addresses">
                            <list>
                                <value>127.0.0.1:47600</value>
                            </list>
                        </property>
                    </bean>
                </property>
            </bean>
        </property>

        <!-- Other settings -->
    </bean>

    <!-- Client node for connecting to database with traces. -->
    <bean class="org.apache.ignite.configuration.IgniteConfiguration" name="TRACES_IGNITE_CONFIG">
        <property name="clientMode" value="true"/>

        <!-- Setup discovery to cluster with traces. -->
        <property name="discoverySpi">
            <bean class="org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi">
                <property name="localPort" value="47700"/>
                <property name="ipFinder">
                    <bean class="org.apache.ignite.spi.discovery.tcp.ipfinder.vm.TcpDiscoveryVmIpFinder">
                        <property name="addresses">
                            <list>
                                <value>127.0.0.1:47700</value>
                            </list>
                        </property>
                    </bean>
                </property>
            </bean>
        </property>

        <!-- Other settings -->
    </bean>

    <!-- Client node for connecting to database with compute. -->
        <bean class="org.apache.ignite.configuration.IgniteConfiguration" name="COMPUTE_IGNITE_CONFIG">
            <property name="clientMode" value="true"/>

            <!-- Setup discovery to cluster with compute. -->
            <property name="discoverySpi">
                <bean class="org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi">
                    <property name="localPort" value="47800"/>
                    <property name="ipFinder">
                        <bean class="org.apache.ignite.spi.discovery.tcp.ipfinder.vm.TcpDiscoveryVmIpFinder">
                            <property name="addresses">
                                <list>
                                    <value>127.0.0.1:47800</value>
                                </list>
                            </property>
                        </bean>
                    </property>
                </bean>
            </property>

            <!-- Other settings -->
        </bean>
</beans>
